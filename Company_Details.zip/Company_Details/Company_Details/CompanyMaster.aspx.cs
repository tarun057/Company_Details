﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace Company_Details
{
    public partial class CompanyMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            //string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
            //string contentType = FileUpload1.PostedFile.ContentType;
            //using (Stream fs = FileUpload1.PostedFile.InputStream)
            //{
            //    using (BinaryReader br = new BinaryReader(fs))
            //    {
            //        byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    
                    
                 string constr =  Convert.ToString(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                    
                      using (SqlConnection con = new SqlConnection(constr))
                      
                    {
                        string query = "insert into CompanyMaster values (@Name, @Status)";
                        using (SqlCommand cmd = new SqlCommand(query))
                        {
                            cmd.Connection = con;
                            cmd.Parameters.AddWithValue("@Name", TextBox1.Text);
                            //cmd.Parameters.AddWithValue("@ContentType", contentType);
                            cmd.Parameters.AddWithValue("@Status", TextBox2.Text);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
    }
            
        }
    